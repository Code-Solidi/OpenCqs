﻿namespace OpenCqs2.Policies
{
    public interface IPolicy
    {
        void Initialize<T>();
    }
}