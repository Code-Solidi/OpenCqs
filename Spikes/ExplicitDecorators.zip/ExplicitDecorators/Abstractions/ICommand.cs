﻿namespace OpenCqs2.Abstractions
{
    public interface ICommand
    {
    }
}