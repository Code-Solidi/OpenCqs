﻿/*
 * Copyright (c) 2021-2022 Code Solidi Ltd. All rights reserved.
 * Licensed under the OSL-3.0, https://opensource.org/licenses/OSL-3.0.
 */

using Microsoft.Extensions.Logging;

using OpenCqs;

using OpenCqs.Decorators.Exceptions;

using System;
using System.Diagnostics;

namespace OpenCqsDemo.Decorators.Diagnostics
{
    /// <summary>
    /// The stop watch query handler.
    /// </summary>
    public class StopWatchQueryHandler<TQuery, TResult> : IQueryHandler<TQuery, TResult> where TQuery : IQuery
    {
        private readonly ILogger logger;

        /// <summary>
        /// Gets or sets the handler.
        /// </summary>
        public IQueryHandler<TQuery, TResult> Handler { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="StopWatchQueryHandler"/> class.
        /// </summary>
        /// <param name="queryHandler">The query handler.</param>
        /// <param name="logger"></param>
        public StopWatchQueryHandler(IQueryHandler<TQuery, TResult> queryHandler, ILogger logger)
        {
            this.Handler = queryHandler ?? throw new ArgumentNullException(nameof(queryHandler));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Handles the query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <returns>A TResult.</returns>
        public virtual TResult Handle(TQuery query)
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();

            var result = this.Handler.Handle(query);

            stopWatch.Stop();
            var ts = stopWatch.Elapsed;

            this.logger.LogDebug($"Execution time {(ts.TotalMilliseconds / 1000):0.0000000}s.");

            return result;
        }
    }
}